"""Routes FastAPI pour l'application."""

from app.routes import agencies, listings, scraper

__all__ = ["agencies", "listings", "scraper"]
