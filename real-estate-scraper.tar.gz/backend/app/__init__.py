"""Application Real Estate Scraper."""

__version__ = "1.0.0"
