import React from 'react';
import Search from './pages/Search';
import './App.css';

function App() {
  return (
    <div className="app">
      <Search />
    </div>
  );
}

export default App;
